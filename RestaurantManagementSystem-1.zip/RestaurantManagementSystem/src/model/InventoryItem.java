/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model; 
// Specifies that this class belongs to the "model" package

public class InventoryItem {
    // Declares a public class named InventoryItem

    private int id;
    // Stores the unique ID of the inventory item

    private String name;
    // Stores the name of the inventory item

    private int quantity;
    // Stores the available quantity of the item

    public InventoryItem(int id, String name, int quantity) {
        // Constructor: used to create and initialize an InventoryItem object

        this.id = id;
        // Assigns the passed id value to the class variable id

        this.name = name;
        // Assigns the passed name value to the class variable name

        this.quantity = quantity;
        // Assigns the passed quantity value to the class variable quantity
    }

    public int getId() {
        // Getter method to return the item ID

        return id;
        // Returns the value of id
    }

    public void setId(int id) {
        // Setter method to update the item ID

        this.id = id;
        // Sets the class variable id to the new value
    }

    public String getName() {
        // Getter method to return the item name

        return name;
        // Returns the value of name
    }

    public void setName(String name) {
        // Setter method to update the item name

        this.name = name;
        // Sets the class variable name to the new value
    }

    public int getQuantity() {
        // Getter method to return the item quantity

        return quantity;
        // Returns the value of quantity
    }

    public void setQuantity(int quantity) {
        // Setter method to update the item quantity

        this.quantity = quantity;
        // Sets the class variable quantity to the new value
    }

    @Override
    public String toString() {
        // Overrides the default toString() method to return custom text

        return "ID: " + id + ", Name: " + name + ", Quantity: " + quantity;
        // Returns item details as a readable string
    }
}