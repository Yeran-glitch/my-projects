/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author sahan
 */
public class User {
    private String username = "admin";
    private String password = "admin123";

    public String getUsername(){
        return username;
    }
    
    public String getPassword(){
        return password;
    }
}
