/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


// Declares that this class belongs to the 'model' package
package model;

// Definition of the MenuItem class
// This class represents a single item in the restaurant menu
public class MenuItem {

    // Private variable to store the unique ID of the menu item
    // Using String because item IDs can be alphanumeric (e.g., M001)
    private String id;

    // Private variable to store the name of the menu item
    private String name;

    // Private variable to store the price of the menu item
    // double is used to allow decimal values (e.g., 250.50)
    private double price;

    // Constructor of the MenuItem class
    // This is used to create and initialize a MenuItem object
    public MenuItem(String id, String name, double price) {

        // Assigns the passed id value to the class variable id
        this.id = id;

        // Assigns the passed name value to the class variable name
        this.name = name;

        // Assigns the passed price value to the class variable price
        this.price = price;
    }

    // Getter method to return the menu item's ID
    public String getId() {

        // Returns the value of id
        return id;
    }

    // Setter method to update the menu item's ID
    public void setId(String id) {

        // Updates the class variable id with the new value
        this.id = id;
    }

    // Getter method to return the menu item's name
    public String getName() {

        // Returns the value of name
        return name;
    }

    // Setter method to update the menu item's name
    public void setName(String name) {

        // Updates the class variable name with the new value
        this.name = name;
    }

    // Getter method to return the menu item's price
    public double getPrice() {

        // Returns the value of price
        return price;
    }

    // Setter method to update the menu item's price
    public void setPrice(double price) {

        // Updates the class variable price with the new value
        this.price = price;
    }

    // Overrides the default toString() method of the Object class
    // This method defines how the object will be displayed as text
    @Override
    public String toString() {

        // Returns a formatted string containing item ID, name, and price
        // This is useful when displaying menu items in lists or tables
        return "ID: " + id + ", Name: " + name + ", Price: $" + price;
    }
}
