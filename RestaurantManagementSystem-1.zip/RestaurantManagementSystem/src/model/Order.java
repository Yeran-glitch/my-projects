/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


package model;

import java.util.List;

public class Order {
    private String customerName;
    private String contact;
    private List<MenuItem> items;
    private double additionalCharges;
    private double discount;
    private double total;

    public Order(String customerName, String contact, List<MenuItem> items) {
        this.customerName = customerName;
        this.contact = contact;
        this.items = items;
        this.additionalCharges = 0;
        this.discount = 0;
        this.total = 0;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public List<MenuItem> getItems() {
        return items;
    }

    public void setItems(List<MenuItem> items) {
        this.items = items;
    }

    public double getAdditionalCharges() {
        return additionalCharges;
    }

    public void setAdditionalCharges(double additionalCharges) {
        this.additionalCharges = additionalCharges;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public void calculateTotal() {
        double sum = 0;
        for (MenuItem item : items) {
            sum += item.getPrice();
        }
        total = sum + additionalCharges - discount;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Customer: ").append(customerName).append(", Contact: ").append(contact).append("\n");
        sb.append("Items:\n");
        for (MenuItem item : items) {
            sb.append(item.toString()).append("\n");
        }
        sb.append("Additional Charges: $").append(additionalCharges).append("\n");
        sb.append("Discount: $").append(discount).append("\n");
        sb.append("Total: $").append(total);
        return sb.toString();
    }
}
