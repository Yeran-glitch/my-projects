/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model; 
// Declares that this class belongs to the "model" package

import java.util.ArrayList;
import java.util.List;
// Imports List interface and ArrayList class for storing menu items

public class MenuManager {
    // MenuManager class is responsible for managing menu items

    private static List<MenuItem> menuItems = new ArrayList<>();
    // Static list that stores all MenuItem objects
    // Static means the list is shared across the entire application

    public static List<MenuItem> getMenuItems() {
        // Returns the complete list of menu items
        return menuItems;
    }

    public static void addMenuItem(MenuItem item) {
        // Adds a new MenuItem to the menu list

        for (MenuItem mi : menuItems) {
            // Loop through all existing menu items

            if (mi.getId().equals(item.getId())) {
                // Checks if any existing item has the same ID as the new item

                throw new IllegalArgumentException("Item ID already exists.");
                // Throws an exception if duplicate ID is found
            }
        }

        menuItems.add(item);
        // Adds the new item to the list if ID is unique
    }

    public static void removeMenuItem(String id) {
        // Removes a menu item based on its ID

        menuItems.removeIf(item -> item.getId().equals(id));
        // removeIf uses a lambda expression to remove the item
        // whose ID matches the given ID
    }

    public static MenuItem getMenuItem(String id) {
        // Retrieves a MenuItem object using its ID

        for (MenuItem item : menuItems) {
            // Loop through all menu items

            if (item.getId().equals(id)) {
                // If ID matches, return the item

                return item;
            }
        }

        return null;
        // Returns null if no matching item is found
    }

    public static void updateMenuItem(String id, String name, double price) {
        // Updates the name and price of an existing menu item

        MenuItem item = getMenuItem(id);
        // Retrieves the menu item using its ID

        if (item != null) {
            // Checks if the item exists

            item.setName(name);
            // Updates the item name

            item.setPrice(price);
            // Updates the item price
        }
    }
}
