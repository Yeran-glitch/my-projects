/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;
import java.util.List;

public class EmployeeManager {
    private static List<Employee> employees = new ArrayList<>();

    public static List<Employee> getEmployees() {
        return employees;
    }

    public static void addEmployee(Employee emp) {
        for (Employee e : employees) {
            if (e.getEmpNo() == emp.getEmpNo()) {
                throw new IllegalArgumentException("Employee Number already exists.");
            }
        }
        employees.add(emp);
    }

    public static void removeEmployee(int empNo) {
        employees.removeIf(emp -> emp.getEmpNo() == empNo);
    }

    public static Employee getEmployee(int empNo) {
        for (Employee emp : employees) {
            if (emp.getEmpNo() == empNo) {
                return emp;
            }
        }
        return null;
    }

    public static void updateEmployee(int empNo, String name, String nic, String address, String contact, double basicSalary) {
        Employee emp = getEmployee(empNo);
        if (emp != null) {
            emp.setName(name);
            emp.setNic(nic);
            emp.setAddress(address);
            emp.setContact(contact);
            emp.setBasicSalary(basicSalary);
        }
    }

    public static void addBonusAndOT(int empNo, double bonus, double otHours) {
        Employee emp = getEmployee(empNo);
        if (emp != null) {
            emp.setBonus(bonus);
            emp.setOtHours(otHours);
        }
    }
}
