/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package model; 
// Specifies that this class belongs to the 'model' package

import java.util.ArrayList;
import java.util.List;
// Imports List interface and ArrayList class to store inventory items

public class InventoryManager {
    // InventoryManager is a utility class to manage inventory items

    private static List<InventoryItem> inventoryItems = new ArrayList<>();
    // A static list to store all InventoryItem objects
    // 'static' means the list is shared across the entire application

    public static List<InventoryItem> getInventoryItems() {
        // Returns the complete inventory item list
        return inventoryItems;
    }

    public static void addInventoryItem(InventoryItem item) {
        // Adds a new inventory item to the list

        for (InventoryItem ii : inventoryItems) {
            // Loop through each existing inventory item

            if (ii.getId() == item.getId()) {
                // Check if an item with the same ID already exists

                throw new IllegalArgumentException("Item ID already exists.");
                // Throws an error to prevent duplicate item IDs
            }
        }

        inventoryItems.add(item);
        // Adds the new item to the inventory list if ID is unique
    }

    public static void removeInventoryItem(int id) {
        // Removes an inventory item based on its ID

        inventoryItems.removeIf(item -> item.getId() == id);
        // Uses a lambda expression to remove the item whose ID matches
    }

    public static InventoryItem getInventoryItem(int id) {
        // Retrieves a single inventory item by ID

        for (InventoryItem item : inventoryItems) {
            // Loop through all inventory items

            if (item.getId() == id) {
                // If item ID matches the given ID
                return item;
                // Return the matching InventoryItem
            }
        }

        return null;
        // Returns null if no matching item is found
    }

    public static void updateInventoryItem(int id, String name, int quantity) {
        // Updates an existing inventory item's name and quantity

        InventoryItem item = getInventoryItem(id);
        // Fetch the item using its ID

        if (item != null) {
            // Check if the item exists

            item.setName(name);
            // Update the item's name

            item.setQuantity(quantity);
            // Update the item's quantity
        }
    }
}
