/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

public class Employee {
    private int empNo;
    private String name;
    private String nic;
    private String address;
    private String contact;
    private double basicSalary;
    private double bonus;
    private double otHours;

    public Employee(int empNo, String name, String nic, String address, String contact, double basicSalary) {
        this.empNo = empNo;
        this.name = name;
        this.nic = nic;
        this.address = address;
        this.contact = contact;
        this.basicSalary = basicSalary;
        this.bonus = 0;
        this.otHours = 0;
    }

    public int getEmpNo() {
        return empNo;
    }

    public void setEmpNo(int empNo) {
        this.empNo = empNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNic() {
        return nic;
    }

    public void setNic(String nic) {
        this.nic = nic;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public double getBasicSalary() {
        return basicSalary;
    }

    public void setBasicSalary(double basicSalary) {
        this.basicSalary = basicSalary;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    public double getOtHours() {
        return otHours;
    }

    public void setOtHours(double otHours) {
        this.otHours = otHours;
    }

    public double calculateTotalPay() {
        double otRate = 100.0; // Assuming OT rate per hour
        return basicSalary + bonus + (otHours * otRate);
    }

    @Override
    public String toString() {
        return "EmpNo: " + empNo + ", Name: " + name + ", NIC: " + nic + ", Address: " + address + ", Contact: " + contact + ", Basic Salary: $" + basicSalary + ", Bonus: $" + bonus + ", OT Hours: " + otHours + ", Total Pay: $" + calculateTotalPay();
    }
}
